/**
 * CS 320 - Module Five Milestone
 * File: AppointmentService.java
 * Author: Adryan Knight
 *
 * In-memory appointment service:
 * - add appointments with unique IDs
 * - delete appointments by ID
 * No UI or database required.
 */
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

    private final Map<String, Appointment> appointments = new HashMap<>();

    /** Adds an already-constructed appointment (ID must be unique). */
    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment must not be null.");
        }
        String id = appointment.getAppointmentId();
        if (appointments.containsKey(id)) {
            throw new IllegalArgumentException("Duplicate appointment ID: " + id);
        }
        appointments.put(id, appointment);
    }

    /** Convenience overload to build and add an appointment. */
    public void addAppointment(String id, Date date, String description) {
        Appointment appt = new Appointment(id, date, description);
        addAppointment(appt);
    }

    /** Deletes an appointment by ID. Returns true if removed, else false. */
    public boolean deleteAppointment(String id) {
        return appointments.remove(id) != null;
    }

    /** Read-only view (useful for testing). */
    public Map<String, Appointment> getAll() {
        return Collections.unmodifiableMap(appointments);
    }

    /** Optional helper for tests. */
    public Appointment getById(String id) {
        return appointments.get(id);
    }

    public int size() {
        return appointments.size();
    }
}
