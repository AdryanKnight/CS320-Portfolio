/**
 * CS 320 - Module Five Milestone
 * File: Appointment.java
 * Author: Adryan Knight
 *
 * Requirements:
 * - appointmentId: required, unique, max 10 chars, not null, not updatable
 * - appointmentDate: required, not null, may not be in the past
 * - description: required, not null, max 50 chars
 *
 * Notes:
 * - Uses java.util.Date and checks against new Date() to prevent past dates.
 */
import java.util.Date;
import java.util.Objects;

public class Appointment {

    private final String appointmentId;     // not updatable
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        validateId(appointmentId);
        validateDate(appointmentDate);
        validateDescription(description);
        this.appointmentId = appointmentId;
        this.appointmentDate = new Date(appointmentDate.getTime());
        this.description = description;
    }

    // --- Validation helpers ---
    private static void validateId(String appointmentId) {
        if (appointmentId == null || appointmentId.trim().isEmpty()) {
            throw new IllegalArgumentException("Appointment ID must not be null or empty.");
        }
        if (appointmentId.length() > 10) {
            throw new IllegalArgumentException("Appointment ID must be 10 characters or fewer.");
        }
    }

    private static void validateDate(Date appointmentDate) {
        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date must not be null.");
        }
        Date now = new Date();
        if (appointmentDate.before(now)) {
            throw new IllegalArgumentException("Appointment date cannot be in the past.");
        }
    }

    private static void validateDescription(String description) {
        if (description == null) {
            throw new IllegalArgumentException("Description must not be null.");
        }
        if (description.length() > 50) {
            throw new IllegalArgumentException("Description must be 50 characters or fewer.");
        }
    }

    // --- Getters (ID has no setter by design) ---
    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return new Date(appointmentDate.getTime());
    }

    public String getDescription() {
        return description;
    }

    // --- Setters for fields that may change ---
    public void setAppointmentDate(Date appointmentDate) {
        validateDate(appointmentDate);
        this.appointmentDate = new Date(appointmentDate.getTime());
    }

    public void setDescription(String description) {
        validateDescription(description);
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Appointment)) return false;
        Appointment that = (Appointment) o;
        // Uniqueness is based on immutable ID
        return appointmentId.equals(that.appointmentId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appointmentId);
    }

    @Override
    public String toString() {
        return "Appointment{" +
                "appointmentId='" + appointmentId + '\'' +
                ", appointmentDate=" + appointmentDate +
                ", description='" + description + '\'' +
                '}';
    }
}
