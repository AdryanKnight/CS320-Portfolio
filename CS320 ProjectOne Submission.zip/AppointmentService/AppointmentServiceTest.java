/**
 * CS 320 - Module Five Milestone
 * File: AppointmentServiceTest.java
 * Author: Adryan Knight
 *
 * JUnit tests for AppointmentService.
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

public class AppointmentServiceTest {

    private Date futureDate(int daysAhead) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, daysAhead);
        return cal.getTime();
    }

    @Test
    void addAppointment_uniqueId_succeeds() {
        AppointmentService svc = new AppointmentService();
        svc.addAppointment("ID1", futureDate(3), "Dentist");
        assertEquals(1, svc.size());
        assertNotNull(svc.getById("ID1"));
    }

    @Test
    void addAppointment_duplicateId_throws() {
        AppointmentService svc = new AppointmentService();
        svc.addAppointment("ID1", futureDate(3), "Dentist");
        assertThrows(IllegalArgumentException.class, () ->
                svc.addAppointment("ID1", futureDate(4), "Doctor")
        );
    }

    @Test
    void deleteAppointment_byId_removesOnlyTarget() {
        AppointmentService svc = new AppointmentService();
        svc.addAppointment("A1", futureDate(2), "Checkup");
        svc.addAppointment("A2", futureDate(3), "Consult");
        assertTrue(svc.deleteAppointment("A1"));
        assertNull(svc.getById("A1"));
        assertNotNull(svc.getById("A2"));
        assertEquals(1, svc.size());
    }

    @Test
    void deleteAppointment_missingId_returnsFalse() {
        AppointmentService svc = new AppointmentService();
        svc.addAppointment("A1", futureDate(2), "Checkup");
        assertFalse(svc.deleteAppointment("NOPE"));
        assertEquals(1, svc.size());
    }
}
