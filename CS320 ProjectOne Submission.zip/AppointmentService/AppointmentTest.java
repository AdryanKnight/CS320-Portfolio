/**
 * CS 320 - Module Five Milestone
 * File: AppointmentTest.java
 * Author: Adryan Knight
 *
 * JUnit tests for Appointment.
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

public class AppointmentTest {

    private Date futureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 2);
        return cal.getTime();
    }

    private Date pastDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, -2);
        return cal.getTime();
    }

    @Test
    void constructor_validInputs_succeeds() {
        Appointment a = new Appointment("A123", futureDate(), "Routine check");
        assertEquals("A123", a.getAppointmentId());
        assertEquals("Routine check", a.getDescription());
        assertTrue(a.getAppointmentDate().after(new Date(System.currentTimeMillis() - 1000)));
    }

    @Test
    void id_nullOrTooLong_throws() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate(), "desc"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("", futureDate(), "desc"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("ABCDEFGHIJK", futureDate(), "desc")); // 11 chars
    }

    @Test
    void date_nullOrPast_throws() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("ID1", null, "desc"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("ID1", pastDate(), "desc"));
    }

    @Test
    void description_nullOrTooLong_throws() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("ID1", futureDate(), null));
        String longDesc = "x".repeat(51);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("ID1", futureDate(), longDesc));
    }

    @Test
    void setters_enforceValidation() {
        Appointment a = new Appointment("A1", futureDate(), "ok");
        // description ok
        a.setDescription("Updated");
        assertEquals("Updated", a.getDescription());

        // too long description
        String longDesc = "y".repeat(51);
        assertThrows(IllegalArgumentException.class, () -> a.setDescription(longDesc));

        // past date
        assertThrows(IllegalArgumentException.class, () -> a.setAppointmentDate(pastDate()));

        // future date ok
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 5);
        Date later = cal.getTime();
        a.setAppointmentDate(later);
        assertEquals(later, a.getAppointmentDate());
    }
}
