public class Task {
    private final String id;           // max 10 chars, non-null, not updatable
    private String name;               // max 20 chars, non-null
    private String description;        // max 50 chars, non-null

    public Task(String id, String name, String description) {
        validateId(id);
        validateName(name);
        validateDescription(description);
        this.id = id;
        this.name = name;
        this.description = description;
    }

    private void validateId(String id) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("Task id must be non-null/non-blank");
        }
        if (id.length() > 10) {
            throw new IllegalArgumentException("Task id length must be <= 10");
        }
    }

    private void validateName(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Task name must be non-null/non-blank");
        }
        if (name.length() > 20) {
            throw new IllegalArgumentException("Task name length must be <= 20");
        }
    }

    private void validateDescription(String description) {
        if (description == null || description.isBlank()) {
            throw new IllegalArgumentException("Task description must be non-null/non-blank");
        }
        if (description.length() > 50) {
            throw new IllegalArgumentException("Task description length must be <= 50");
        }
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // Updatable fields: name and description
    public void setName(String name) {
        validateName(name);
        this.name = name;
    }

    public void setDescription(String description) {
        validateDescription(description);
        this.description = description;
    }
}