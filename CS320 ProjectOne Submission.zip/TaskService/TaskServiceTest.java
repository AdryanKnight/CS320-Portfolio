import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.NoSuchElementException;

public class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    void setup() {
        service = new TaskService();
    }

    @Test
    void addTaskWithUniqueIdSucceeds() {
        service.addTask("1", "Task1", "First task");
        assertEquals(1, service.size());
        assertNotNull(service.getTask("1"));
    }

    @Test
    void addingDuplicateIdThrows() {
        service.addTask("1", "Task1", "First task");
        assertThrows(IllegalArgumentException.class,
            () -> service.addTask("1", "Other", "Duplicate id"));
    }

    @Test
    void deleteTaskByIdRemoves() {
        service.addTask("1", "Task1", "First task");
        service.deleteTask("1");
        assertEquals(0, service.size());
        assertNull(service.getTask("1"));
    }

    @Test
    void deleteNonexistentThrows() {
        assertThrows(NoSuchElementException.class, () -> service.deleteTask("nope"));
    }

    @Test
    void updateNameAndDescription() {
        service.addTask("1", "Task1", "First task");
        service.updateTaskName("1", "Updated Name");
        service.updateTaskDescription("1", "Updated Description");
        assertEquals("Updated Name", service.getTask("1").getName());
        assertEquals("Updated Description", service.getTask("1").getDescription());
    }

    @Test
    void updateOnMissingTaskThrows() {
        assertThrows(NoSuchElementException.class, () -> service.updateTaskName("x", "n"));
        assertThrows(NoSuchElementException.class, () -> service.updateTaskDescription("x", "d"));
    }
}