import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    // Convenience: create and add a task using fields
    public Task addTask(String id, String name, String description) {
        Task t = new Task(id, name, description);
        return addTask(t);
    }

    // Add an existing Task, ensuring unique ID
    public Task addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task must be non-null");
        }
        String id = task.getId();
        if (tasks.containsKey(id)) {
            throw new IllegalArgumentException("Task id must be unique: " + id);
        }
        tasks.put(id, task);
        return task;
    }

    // Delete by ID (throws if not present)
    public void deleteTask(String id) {
        if (id == null) {
            throw new IllegalArgumentException("id must be non-null");
        }
        if (tasks.remove(id) == null) {
            throw new NoSuchElementException("No task with id: " + id);
        }
    }

    // Update name for task ID
    public void updateTaskName(String id, String newName) {
        Task t = getExisting(id);
        t.setName(newName);
    }

    // Update description for task ID
    public void updateTaskDescription(String id, String newDescription) {
        Task t = getExisting(id);
        t.setDescription(newDescription);
    }

    // Helper to retrieve existing task or throw
    private Task getExisting(String id) {
        if (id == null) throw new IllegalArgumentException("id must be non-null");
        Task t = tasks.get(id);
        if (t == null) throw new NoSuchElementException("No task with id: " + id);
        return t;
    }

    // Accessor for tests
    public Task getTask(String id) {
        return tasks.get(id);
    }

    public int size() {
        return tasks.size();
    }
}