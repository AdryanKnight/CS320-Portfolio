import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void constructorAndGettersWork() {
        Task t = new Task("ABC123", "Pay bills", "Pay electricity and water bills");
        assertEquals("ABC123", t.getId());
        assertEquals("Pay bills", t.getName());
        assertEquals("Pay electricity and water bills", t.getDescription());
    }

    @Test
    void idCannotBeNullOrTooLong() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "n", "d"));
        assertThrows(IllegalArgumentException.class, () -> new Task("", "n", "d"));
        assertThrows(IllegalArgumentException.class, () -> new Task("01234567890", "n", "d")); // 11 chars
    }

    @Test
    void nameConstraintsEnforced() {
        assertThrows(IllegalArgumentException.class, () -> new Task("ID", null, "d"));
        assertThrows(IllegalArgumentException.class, () -> new Task("ID", "", "d"));
        String longName = "X".repeat(21);
        assertThrows(IllegalArgumentException.class, () -> new Task("ID", longName, "d"));
    }

    @Test
    void descriptionConstraintsEnforced() {
        assertThrows(IllegalArgumentException.class, () -> new Task("ID", "Name", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("ID", "Name", ""));
        String longDesc = "Y".repeat(51);
        assertThrows(IllegalArgumentException.class, () -> new Task("ID", "Name", longDesc));
    }

    @Test
    void settersValidateAndUpdate() {
        Task t = new Task("ID", "Old", "Old description");
        t.setName("New Name");
        t.setDescription("New description");
        assertEquals("New Name", t.getName());
        assertEquals("New description", t.getDescription());

        assertThrows(IllegalArgumentException.class, () -> t.setName(""));
        assertThrows(IllegalArgumentException.class, () -> t.setDescription(""));
    }
}