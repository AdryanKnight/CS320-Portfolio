CS 320 Project One – ContactService, TaskService, AppointmentService

Contents:
- ContactService/
    - Contact.java
    - ContactService.java
    - ContactTest.java
    - ContactServiceTest.java
- TaskService/
    - Task.java
    - TaskService.java
    - TaskTest.java
    - TaskServiceTest.java
- AppointmentService/
    - Appointment.java
    - AppointmentService.java
    - AppointmentTest.java
    - AppointmentServiceTest.java

Notes:
- These files are the combined artifacts from Milestones 3, 4, and 5.
- Import each set into your Codio/IDE as needed and run the JUnit tests.
- Ensure your package declarations (if any) match your project structure.
