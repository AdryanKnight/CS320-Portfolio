/*
 * CS 320 – Module Three Milestone
 * Author: Adryan Knight
 * File: ContactTest.java
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    void validContactIsCreated() {
        Contact c = new Contact("12345", "Ada", "Lovelace", "0123456789", "12 Computing Way");
        assertEquals("12345", c.getContactID());
        assertEquals("Ada", c.getFirstName());
        assertEquals("Lovelace", c.getLastName());
        assertEquals("0123456789", c.getPhone());
        assertEquals("12 Computing Way", c.getAddress());
    }

    // ----- ID rules -----
    @Test
    void idCannotBeNullOrTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact(null, "Ada", "Lovelace", "0123456789", "Addr"));
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("ABCDEFGHIJK", "Ada", "Lovelace", "0123456789", "Addr")); // 11 chars
    }

    // ----- Name rules -----
    @Test
    void firstAndLastNameMax10AndNotNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", null, "Last", "0123456789", "Addr"));
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "FirstnameTooLong", "Last", "0123456789", "Addr"));

        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "First", null, "0123456789", "Addr"));
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "First", "LastnameTooLong", "0123456789", "Addr"));
    }

    // ----- Phone rules -----
    @Test
    void phoneMustBeExactly10Digits() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "A", "B", "123456789", "Addr")); // 9
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "A", "B", "12345678901", "Addr")); // 11
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "A", "B", "12345abcde", "Addr")); // non-digits
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "A", "B", null, "Addr")); // null
    }

    // ----- Address rules -----
    @Test
    void addressMax30AndNotNull() {
        String thirtyOne = "1234567890123456789012345678901";
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "A", "B", "0123456789", thirtyOne));
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "A", "B", "0123456789", null));
    }

    // ----- Updatable fields work; ID is immutable (no setter to call) -----
    @Test
    void settersValidateAndUpdate() {
        Contact c = new Contact("9", "A", "B", "0123456789", "Addr");
        c.setFirstName("Alan");
        c.setLastName("Turing");
        c.setPhone("1112223333");
        c.setAddress("Bletchley Park");
        assertEquals("Alan", c.getFirstName());
        assertEquals("Turing", c.getLastName());
        assertEquals("1112223333", c.getPhone());
        assertEquals("Bletchley Park", c.getAddress());

        // Invalid updates should throw
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName("NameTooLong!!"));
        assertThrows(IllegalArgumentException.class, () -> c.setLastName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("short"));
        assertThrows(IllegalArgumentException.class, () -> c.setAddress(""));
    }
}
