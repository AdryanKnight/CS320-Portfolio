/*
 * CS 320 – Module Three Milestone
 * Author: Adryan Knight
 * File: ContactService.java
 *
 * Requirements:
 *  - Add contacts with a unique ID
 *  - Delete contacts by ID
 *  - Update firstName, lastName, phone, address by ID
 *  - In-memory storage (no DB)
 */

import java.util.HashMap;
import java.util.Map;

public class ContactService {

    private final Map<String, Contact> contacts = new HashMap<>();

    // Helper: fetch by ID or throw
    private Contact getRequired(String contactID) {
        Contact c = contacts.get(contactID);
        if (c == null) throw new IllegalArgumentException("Contact with ID '" + contactID + "' not found.");
        return c;
    }

    // Create+add from fields (convenience)
    public Contact addContact(String contactID, String firstName, String lastName, String phone, String address) {
        if (contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact ID must be unique: " + contactID);
        }
        Contact c = new Contact(contactID, firstName, lastName, phone, address);
        contacts.put(contactID, c);
        return c;
    }

    // Add an existing Contact instance
    public void addContact(Contact contact) {
        if (contact == null) throw new IllegalArgumentException("Contact cannot be null.");
        String id = contact.getContactID();
        if (contacts.containsKey(id)) {
            throw new IllegalArgumentException("Contact ID must be unique: " + id);
        }
        contacts.put(id, contact);
    }

    // Delete
    public void deleteContact(String contactID) {
        if (contacts.remove(contactID) == null) {
            throw new IllegalArgumentException("Cannot delete; ID not found: " + contactID);
        }
    }

    // Updates
    public void updateFirstName(String contactID, String newFirst) {
        getRequired(contactID).setFirstName(newFirst);
    }

    public void updateLastName(String contactID, String newLast) {
        getRequired(contactID).setLastName(newLast);
    }

    public void updatePhone(String contactID, String newPhone) {
        getRequired(contactID).setPhone(newPhone);
    }

    public void updateAddress(String contactID, String newAddress) {
        getRequired(contactID).setAddress(newAddress);
    }

    // Optional: retrieve (useful for tests)
    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }

    // Optional: size (useful for tests)
    public int size() { return contacts.size(); }
}
