/*
 * CS 320 – Module Three Milestone
 * Author: Adryan Knight
 * File: Contact.java
 *
 * Requirements:
 *  - contactID: required, unique, <= 10 chars, not null, not updatable
 *  - firstName: required, <= 10 chars, not null
 *  - lastName:  required, <= 10 chars, not null
 *  - phone:     required, exactly 10 digits, not null
 *  - address:   required, <= 30 chars, not null
 */

public class Contact {

    private final String contactID;      // not updatable
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    public Contact(String contactID, String firstName, String lastName, String phone, String address) {
        this.contactID = validateId(contactID);
        this.firstName = validateName(firstName, "First name");
        this.lastName  = validateName(lastName, "Last name");
        this.phone     = validatePhone(phone);
        this.address   = validateAddress(address);
    }

    // ---- Validators ----
    private String validateId(String id) {
        if (id == null || id.length() == 0 || id.length() > 10) {
            throw new IllegalArgumentException("Contact ID must be 1–10 characters and not null.");
        }
        return id;
    }

    private String validateName(String value, String field) {
        if (value == null || value.length() == 0 || value.length() > 10) {
            throw new IllegalArgumentException(field + " must be 1–10 characters and not null.");
        }
        return value;
    }

    private String validatePhone(String value) {
        if (value == null || value.length() != 10 || !value.chars().allMatch(Character::isDigit)) {
            throw new IllegalArgumentException("Phone must be exactly 10 digits and not null.");
        }
        return value;
    }

    private String validateAddress(String value) {
        if (value == null || value.length() == 0 || value.length() > 30) {
            throw new IllegalArgumentException("Address must be 1–30 characters and not null.");
        }
        return value;
    }

    // ---- Getters (no setter for ID to keep it immutable) ----
    public String getContactID() { return contactID; }
    public String getFirstName() { return firstName; }
    public String getLastName()  { return lastName; }
    public String getPhone()     { return phone; }
    public String getAddress()   { return address; }

    // ---- Setters with validation (updatable fields only) ----
    public void setFirstName(String firstName) { this.firstName = validateName(firstName, "First name"); }
    public void setLastName(String lastName)   { this.lastName = validateName(lastName, "Last name"); }
    public void setPhone(String phone)         { this.phone = validatePhone(phone); }
    public void setAddress(String address)     { this.address = validateAddress(address); }
}
