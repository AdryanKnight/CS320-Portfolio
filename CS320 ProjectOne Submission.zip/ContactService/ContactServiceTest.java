/*
 * CS 320 – Module Three Milestone
 * Author: Adryan Knight
 * File: ContactServiceTest.java
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    private ContactService newServiceWithOne() {
        ContactService svc = new ContactService();
        svc.addContact("1", "Ada", "Lovelace", "0123456789", "12 Computing Way");
        return svc;
    }

    @Test
    void addContactWithUniqueIdSucceeds() {
        ContactService svc = new ContactService();
        svc.addContact("1", "Ada", "Lovelace", "0123456789", "12 Computing Way");
        assertEquals(1, svc.size());
        assertNotNull(svc.getContact("1"));
    }

    @Test
    void addingDuplicateIdThrows() {
        ContactService svc = new ContactService();
        svc.addContact("1", "Ada", "Lovelace", "0123456789", "Addr");
        assertThrows(IllegalArgumentException.class, () ->
                svc.addContact("1", "Alan", "Turing", "1112223333", "Addr2"));
    }

    @Test
    void deleteByIdRemovesContactOrThrowsIfMissing() {
        ContactService svc = newServiceWithOne();
        svc.deleteContact("1");
        assertEquals(0, svc.size());
        assertThrows(IllegalArgumentException.class, () -> svc.deleteContact("1")); // already gone
    }

    @Test
    void updatesWorkForEachField() {
        ContactService svc = newServiceWithOne();

        svc.updateFirstName("1", "Alan");
        svc.updateLastName("1", "Turing");
        svc.updatePhone("1", "1112223333");
        svc.updateAddress("1", "Bletchley Park");

        Contact c = svc.getContact("1");
        assertEquals("Alan", c.getFirstName());
        assertEquals("Turing", c.getLastName());
        assertEquals("1112223333", c.getPhone());
        assertEquals("Bletchley Park", c.getAddress());
    }

    @Test
    void updateOnMissingIdThrows() {
        ContactService svc = newServiceWithOne();
        assertThrows(IllegalArgumentException.class, () -> svc.updateFirstName("2", "X"));
        assertThrows(IllegalArgumentException.class, () -> svc.updateLastName("2", "Y"));
        assertThrows(IllegalArgumentException.class, () -> svc.updatePhone("2", "0123456789"));
        assertThrows(IllegalArgumentException.class, () -> svc.updateAddress("2", "Somewhere"));
    }

    @Test
    void invalidUpdateValuesThrow() {
        ContactService svc = newServiceWithOne();
        assertThrows(IllegalArgumentException.class, () -> svc.updatePhone("1", "badphone"));
        assertThrows(IllegalArgumentException.class, () -> svc.updateFirstName("1", "ThisNameIsTooLong"));
        assertThrows(IllegalArgumentException.class, () -> svc.updateAddress("1", null));
    }
}
